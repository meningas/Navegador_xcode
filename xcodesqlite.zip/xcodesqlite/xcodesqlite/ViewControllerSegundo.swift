//
//  ViewControllerSegundo.swift
//  xcodesqlite
//
//  Created by David on 22/01/2019.
//  Copyright © 2019 luissancar. All rights reserved.
//

import UIKit
import SQLite3

class ViewControllerSegundo: UIViewController, UITableViewDelegate,UITableViewDataSource{
    var db: OpaquePointer?
    var historial = [ObjetoHistorial]()
    var histo: [String] = []
    
    @IBOutlet weak var botonBorrar: UIBarButtonItem!
    
    @IBOutlet weak var histoTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        conectarDB()
        leerValores()
        if (historial.count==0){
            botonBorrar.isEnabled = false;
        }else{
            botonBorrar.isEnabled = true;
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return historial.count
    }
    
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        
        let celda = UITableViewCell(style: UITableViewCell.CellStyle.default,  reuseIdentifier: "celda")
 
        celda.textLabel?.text = historial[indexPath.row].url
        
        return celda
    }
    
    @IBAction func salirhistorial(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func eliminarDatos(_ sender: Any) {
        eliminarHistorial()
        leerValores()
        histoTableView.reloadData()
        botonBorrar.isEnabled = false;
    }
    
    func conectarDB()
    {
        let fileURL = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
            .appendingPathComponent("Historial.sqlite")
        
        if sqlite3_open(fileURL.path, &db) != SQLITE_OK {
            print("Error conectando la base de datos")
        }
        else {
            print("Base de datos conectada")
            if sqlite3_exec(db, "CREATE TABLE IF NOT EXISTS Historial (id INTEGER PRIMARY KEY AUTOINCREMENT, url TEXT)", nil, nil, nil) != SQLITE_OK {
                let errmsg = String(cString: sqlite3_errmsg(db)!)
                print("Error creando la base de datos: \(errmsg)")
            }
        }
        leerValores()
    }
    
    
    func leerValores(){
        
        historial.removeAll()
        
        let queryString = "SELECT * FROM Historial"
        
        var stmt:OpaquePointer?
        
        if sqlite3_prepare(db, queryString, -1, &stmt, nil) != SQLITE_OK{
            let errmsg = String(cString: sqlite3_errmsg(db)!)
            print("Error preparando la sentencia: \(errmsg)")
            return
        }
        
        while(sqlite3_step(stmt) == SQLITE_ROW){
            let id = sqlite3_column_int(stmt, 0)
            let url = String(cString: sqlite3_column_text(stmt, 1))
            
            
            historial.append(ObjetoHistorial(id: Int(id), url: String(describing: url)))
            
        }
        
    }
    func eliminarHistorial()
    {
        let queryString = "DELETE FROM Historial"
        var deleteStatement: OpaquePointer? = nil
        
        if sqlite3_prepare(db, queryString, -1, &deleteStatement, nil) != SQLITE_OK{
            let errmsg = String(cString: sqlite3_errmsg(db)!)
            print(queryString)
            print("Error preparando el insertar: \(errmsg)")
            return
        }
        if sqlite3_prepare_v2(db, queryString, -1, &deleteStatement, nil) == SQLITE_OK {
            if sqlite3_step(deleteStatement) == SQLITE_DONE {
                print("Registro borrado.")
            } else {
                print("No se puede borrar registro.")
            }
        } else {
            print("DELETE statement could not be prepared")
        }
        
        sqlite3_finalize(deleteStatement)
        
    }
    
    class ObjetoHistorial{
        
        var id: Int
        var url: String?
        
        init (id: Int, url: String?)
        {
            self.id = id
            self.url = url
        }
        
    }
}
