//
//  ViewController.swift
//  xcodesqlite
//
//  Created by Nosferatu on 14/01/2019.
//  Copyright © 2019 luissancar. All rights reserved.
//

import UIKit

import SQLite3

import WebKit

class ViewController: UIViewController, UISearchBarDelegate, UIWebViewDelegate {
    var db: OpaquePointer?
    var historial = [ObjetoHistorial]()
    @IBOutlet weak var webview: WKWebView!
    @IBOutlet weak var barraBusqueda: UISearchBar!
    @IBOutlet weak var botonAtras: UIBarButtonItem!
    @IBOutlet weak var botonDelante: UIBarButtonItem!
    
    @IBOutlet weak var botonHistorial: UIBarButtonItem!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        barraBusqueda.delegate = self
        if let myURL = URL(string: "https://www.google.es") {
            let myRequest = URLRequest(url: myURL)
            webview?.load(myRequest)
        }
        crearBD()
        leerValores()
        if (historial.count==0){
            botonHistorial.isEnabled = false;
        }else{
            botonHistorial.isEnabled = true;
        }
        print(historial.count)
        botonAtras.isEnabled = false
        botonDelante.isEnabled = false
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        botonAtras.isEnabled = true
        let com: String = ".com"
        let es: String = ".es"
        let net: String = ".net"
        let http: String = "https://"
        let www: String = "www."
        let google: String = "https://www.google.es/search?q="
        var fin: String = barraBusqueda.text!
        barraBusqueda.resignFirstResponder()
        fin = fin.lowercased()
        
        if fin.contains(com) || fin.contains(es) || fin.contains(net){
            if !fin.contains(www) {
                fin = www + fin
                print(fin)
            }
            if !fin.contains(http){
                fin = http + fin
                print(fin)
            }
        }else{
            fin = google + fin
            print(fin)
        }
        
        if let url = URL(string: fin){
            let myRequest = URLRequest(url: url)
            webview?.load(myRequest)
        }
        barraBusqueda.text = fin
        insertar()
        botonHistorial.isEnabled = true    }
    
    @IBAction func atras(_ sender: Any) {
        if webview.canGoBack{
            webview.goBack()
        }
        comprobarAtras()
    }
    
    func comprobarAtras (){
        if webview.canGoBack{
            print("Puede atras")
            botonDelante.isEnabled = true
        }else{
            botonAtras.isEnabled = false
            botonDelante.isEnabled = true
        }
    }
    
    @IBAction func refrescar(_ sender: Any) {
        webview.reload()
    }
    
    @IBAction func delante(_ sender: Any) {
        if webview.canGoForward{
            webview.goForward()
        }
        comprobarDelante()
    }
    
    func comprobarDelante (){
        if webview.canGoForward{
            print("Puede delante")
            botonAtras.isEnabled = true
        }else{
            botonDelante.isEnabled = false
            botonAtras.isEnabled = true
        }
    }
    
    func crearBD()
    {
        let fileURL = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
            .appendingPathComponent("Historial.sqlite")
        //INDICAMOS SI DIERA ALGUN FALLO AL CONECTARSE
        if sqlite3_open(fileURL.path, &db) != SQLITE_OK {
            print("Error al conectar la bse de datos")
        }
        else {
            print("Base de datos conectada")
            if sqlite3_exec(db, "CREATE TABLE IF NOT EXISTS Historial (id INTEGER PRIMARY KEY AUTOINCREMENT, url TEXT)", nil, nil, nil) != SQLITE_OK {
                let errmsg = String(cString: sqlite3_errmsg(db)!)
                print("Error creando base de datos: \(errmsg)")
            }
        }
        
    }
    
    func insertar()  {
        var stmt: OpaquePointer?
        
        let queryString = "INSERT INTO Historial (url) VALUES ("+"'"+String(barraBusqueda.text!)+"')"
        if sqlite3_prepare(db, queryString, -1, &stmt, nil) != SQLITE_OK{
            let errmsg = String(cString: sqlite3_errmsg(db)!)
            print(queryString)
            print("Error preparando la sentencia: \(errmsg)")
            return
        }
        
        if sqlite3_step(stmt) != SQLITE_DONE {
            let errmsg = String(cString: sqlite3_errmsg(db)!)
            print("Fallo en el insertar: \(errmsg)")
            return
        }
        
        sqlite3_finalize(stmt)
        print("El historial se guardo correctamente")
        
        leerValores()
        
    }

    func leerValores(){
        
        historial.removeAll()
        
        let queryString = "SELECT * FROM Historial"
        
        var stmt:OpaquePointer?
        
        if sqlite3_prepare(db, queryString, -1, &stmt, nil) != SQLITE_OK{
            let errmsg = String(cString: sqlite3_errmsg(db)!)
            print("error preparing insert: \(errmsg)")
            return
        }
        
        while(sqlite3_step(stmt) == SQLITE_ROW){
            let id = sqlite3_column_int(stmt, 0)
            let url = String(cString: sqlite3_column_text(stmt, 1))
            
            historial.append(ObjetoHistorial(id: Int(id), url: String(describing: url)))
            
            print(url)
        }
    }
    
    class ObjetoHistorial{
        var id: Int
        var url: String?
        init (id: Int, url: String?)
        {
            self.id = id
            self.url = url
        }
    }
}
